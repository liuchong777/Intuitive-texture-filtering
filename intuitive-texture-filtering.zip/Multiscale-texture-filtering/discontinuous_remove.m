function out=discontinuous_remove(DJ)
%���δ��յı�Եë��

A=padarray(DJ,[1,1],1);
 B=padarray(DJ,[1,1],0);
[r0,c0]=find(B==1);
L=-1:1;
x=[];
for i=1:length(r0)
    win=A(r0(i)+L,c0(i)+L);
    if sum(win(:))==2
        x=[x;r0(i),c0(i)];
    end
end

while 1
    if isempty(x)
        break
    end
    if B(x(1,1),x(1,2))==0
        x(1,:)=[];
    else
        B=clear_simple(B,x(1,:));
         x(1,:)=[];
    end
end
out=B(2:end-1,2:end-1);

function y=clear_simple(A,x)
% ��xλ����ֵͬ���й������ͬ��ֵ
L=-1:1;
while 1    
    B=[1 x(1)-1 x(2)-1
        2 x(1) x(2)-1
        3 x(1)+1 x(2)-1
        4 x(1)-1 x(2)
        5 x(1)+1 x(2)
        6 x(1)-1 x(2)+1
        7 x(1) x(2)+1
        8 x(1)+1 x(2)+1];%3*3box�г�ȥ���ĵ��һά�Ͷ�άλ�ù�ϵ����
    win= A(x(1)+L,x(2)+L);
    if sum(win(:))==2 
        A(x(1),x(2))=0;
        k=find(win([1:4,6:9])==1);
        x=[B(k,2),B(k,3)];
    elseif sum(win(:))==1 
        A(x(1),x(2))=0;
        break
    else
        break
    end
end
y=A;