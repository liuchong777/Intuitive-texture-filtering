function [x]=FGSBF(im,r,sigma)

 h = fspecial('Gaussia',4);
 im1= imfilter(im,h);
eps=1e-3;
[~,~,channel]=size(im);
if channel==1
    [x]=FGBF(im,im1,r,sigma,eps, 'Gauss');
elseif channel==3
    [x(:,:,1)]=FGBF(im(:,:,1),im1(:,:,1),r, sigma, eps, 'Gauss');
    [x(:,:,2)]=FGBF(im(:,:,2),im1(:,:,2),r, sigma, eps, 'Gauss');
    [x(:,:,3)]=FGBF(im(:,:,3),im1(:,:,3),r, sigma, eps, 'Gauss');
end

function g = FGBF(f,im, sigmar, W, eps, flag) 
 % Fast and Accurate Bilateral Filtering using 
% Gaussian-Polynomial Approximation
%%%%%%%%%%%%%%%%%%%%%%%%
%  f           : input 8-bit grayscale image
%  g           : output of Gaussian bilateral filter
%  b           : output of box bilateral filter
%  sigmas   : width of spatial Gaussian
%  B           : width of spatial box
%  sigmar   : width of range Gaussian
%  eps        : kernel accuracy

%example:
%      Gaussian Bilateral filter:
%      [g,Ng] = GPA(f, sigmar, sigmas, eps, 'Gauss')
%      Box bilateral filter:
%      [b,Nb] = GPA(f, sigmar, B, eps, 'box')

%  Authors:    Kunal Chaudhury, Swapnil Dabhade.
%  Date:       March 25, 2016.
%%%%%%%%%%%%%%%%%%%%%%%%%
if strcmp(flag,'Gauss')
    L=round(3*W);
	Hs=fspecial('gaussian',2*L+1,W);
elseif  strcmp(flag,'box')
    L=W;
	Hs=fspecial('average',2*L+1);
else
	error('not enough arguments');
end 
T = 128;
N = estN(sigmar,T,eps);
f=padarray(double(f),[L,L]);
im=padarray(double(im),[L,L]);
H=(f-T)/sigmar;     
F=exp(-0.5*(H).^2);   
G=ones(size(H));
P=zeros(size(H));  
Q=zeros(size(H));   
Fbar=imfilter(F,Hs);   
for i = 1 : N
	Q=Q+G.*Fbar;
    F=H.*F/sqrt(i);
    Fbar=imfilter(F,Hs);
    P=P+G.*Fbar*sqrt(i);
    G=H.*G/sqrt(i);
end
g= T+sigmar*(P(L+1:end-L,L+1:end-L)./Q(L+1:end-L,L+1:end-L));      
g(g<0)=0;
g(g>255)=255;


function Nest=estN(sigmar,T,eps)
% sigmar        : width of range Gaussian
% T             : dynamic range of image is [0,2T]
% eps           : kernel approximation accuracy 
% Nest          : approximation order
if  sigmar > 70    
    N=10;
elseif sigmar < 5
    N=800;
else 
    lam=(T/sigmar)^2;
    p = log(exp(1)*lam);
    q = -lam - log(eps);
    t = q*exp(-1)/lam;
    W = t - t^2 + 1.5*t^3 - (8/3)*t^4; 
    N = min(max(q/W,10),300);
    if sigmar < 30
        for iter = 1:5  
            N = N - (N*log(N)-p*N-q)/(log(N)+1-p);
        end
    end 
end
Nest = ceil(N);

