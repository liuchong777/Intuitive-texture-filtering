close all
clc
% "Image Texture Filtering via Intuitive Single Click"
%Authors:Chong Liu, Yidan Feng, Cui Yang, Mingqiang Wei, Jun Wang, Ligang Liu


%Only three intuitive points are located on texture region by your perception 
I=(imread('fish.png'));
J=multitexturesmooth(I,15,0.25,10);
imshow([I,uint8(J)])

% I=(imread('00315.jpg'));
% J=multitexturesmooth(I,20,0.25,20);
% imshow(uint8(J))

% I=(imread('00303.jpg'));
% J=multitexturesmooth(I,30,0.25,20);
% imshow(uint8(J))

% I=(imread('00546.jpg'));
% J=multitexturesmooth(I,40,0.25,20);
% imshow(uint8(J))

% I=(imread('kong.png'));
% J=multitexturesmooth(I,10,0.35,50);
% imshow(uint8(J))

